package com.salesforce.tests.dependency.commands;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Dependency {
    protected static Map<String, Dependency> dependencyMap = new HashMap<String, Dependency>();

    private String iName;
    private Set<Dependency> iDependencies = new HashSet<Dependency>();
    private Set<Dependency> iDependents = new HashSet<Dependency>();

    private boolean iInstalled;

    private Dependency(String aName) {
        this.iName = aName;
    }



    public static Dependency getInstance(String aName) {
        Dependency mTarget = dependencyMap.get(aName);
        if (mTarget == null) {
            mTarget = new Dependency(aName);
            dependencyMap.put(aName, mTarget);
        }
        return mTarget;
    }

    public String getName() {
        return iName;
    }

    public boolean isInstalled() {
        return iInstalled;
    }

    public void setInstalled(boolean aInstalled) {
        this.iInstalled = aInstalled;
    }

    public Set<Dependency> getDependents() {
        return iDependents;
    }

    public boolean hasDependents() {
        return !iDependents.isEmpty();
    }

    public boolean hasDependencies() {
        return !iDependencies.isEmpty();
    }

    public Set<Dependency> getDependencies() {
        return iDependencies;
    }

    public boolean addDependency(Dependency d) {
        return iDependencies.add(d);
    }

    public boolean addDependent(Dependency d) {
        return iDependents.add(d);
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Dependency that = (Dependency) o;

        if (iName != null ? !iName.equals(that.iName) : that.iName != null) return false;

        return true;
    }

    @Override
    public String toString() {
        return iName;
    }

    @Override
    public int hashCode() {
        return iName != null ? iName.hashCode() : 0;
    }


    public static Collection<Dependency> getAll() {
        return dependencyMap.values();
    }

    public static Set<Dependency> getInstalled() {
        Set<Dependency> mInstalled = new HashSet<Dependency>();
        for (Dependency tempModule : dependencyMap.values()) {
            if (tempModule.isInstalled())
                mInstalled.add(tempModule);
        }
        return mInstalled;
    }
}
