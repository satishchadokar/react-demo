package com.salesforce.tests.dependency;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.salesforce.tests.dependency.action.DependCommand;
import com.salesforce.tests.dependency.action.ICommand;
import com.salesforce.tests.dependency.action.InstallCommand;
import com.salesforce.tests.dependency.action.ListCommand;
import com.salesforce.tests.dependency.action.RemoveCommand;

/**
 * The entry point for the Test program
 */
public class Main {

	/**
	 * Input 	 */
	private String iInput;

	/**
	 * Output 
	 */
	private PrintStream iOutput = System.out;

	private static Map<String, ICommand> INIT_COMMANDS = new HashMap<>();

	static {

		INIT_COMMANDS.put("DEPEND", new DependCommand());
		INIT_COMMANDS.put("INSTALL", new InstallCommand());
		INIT_COMMANDS.put("REMOVE", new RemoveCommand());
		INIT_COMMANDS.put("LIST", new ListCommand());
	}

	public static void main(String[] args) {

		// read input from stdin
		Scanner scan = new Scanner(System.in);

		while (true) {
			String mline = scan.nextLine();

			// no action for empty input
			if (mline == null || mline.length() == 0) {
				continue;
			}

			// the END command to stop the program
			if ("END".equals(mline)) {
				System.out.println("END");
				break;
			}

			Main mCommandParser = new Main();
			mCommandParser.processCommandByLine(mline);
		}

	}

	/**
	 * Processes a command
	 * 
	 * @param aLine
	 *            line of text representing the command string
	 */
	public void processCommandByLine(String aLine) {
		String[] arguments = aLine.split("[ ]+");
		ICommand mCommand = INIT_COMMANDS.get(arguments[0]);
		if (mCommand == null)
			throw new IllegalArgumentException("Unknown command " + aLine);

		iOutput.println(aLine);
		List<String> mArgs = new LinkedList<String>(Arrays.asList(arguments));
		mArgs.remove(0); // remove command from list
		Map<String, Object> mSuccess = mCommand.execute(mArgs);
		mSuccess.entrySet().stream().forEach(e -> iOutput.println("\t" + e.getKey() + " " + e.getValue()));
	}

}