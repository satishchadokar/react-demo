package com.salesforce.tests.dependency.action;

import java.util.List;
import java.util.Map;

//interface for common for all action
public interface ICommand {
    
    Map<String, Object> execute(List<String> aArgs);
}
