package com.salesforce.tests.dependency.action;


import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.salesforce.tests.dependency.commands.Dependency;

public class DependCommand implements ICommand {


    @Override
    public Map<String, Object> execute(List<String> aArgs) {
        String mDepend = aArgs.get(0);

        Dependency mCurrent = Dependency.getInstance(mDepend);

        for (String tempModule : aArgs.subList(1, aArgs.size())) {
            Dependency mDependency = Dependency.getInstance(tempModule);
            mCurrent.addDependency(mDependency);
            mDependency.addDependent(mCurrent);
        }
        return Collections.emptyMap();
    }

}
