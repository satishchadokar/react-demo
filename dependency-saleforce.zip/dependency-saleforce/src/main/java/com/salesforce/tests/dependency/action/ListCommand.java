package com.salesforce.tests.dependency.action;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.salesforce.tests.dependency.commands.Dependency;


/**
 * process list command
 */
public class ListCommand implements ICommand {


    @Override
    public Map<String, Object> execute(List<String> aArgs) {
        Map<String, Object> mResult = new LinkedHashMap<>();
        Dependency.getInstalled().forEach(m -> mResult.put(m.getName(),""));
        return mResult;
    }

}
