package com.salesforce.tests.dependency.action;



import static java.util.stream.Collectors.toSet;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.salesforce.tests.dependency.commands.Dependency;


/**
 *process remove command
 */
public class RemoveCommand implements ICommand {

    @Override
    public Map<String, Object> execute(List<String> aArgs) {
        Dependency mModuled = Dependency.getInstance(aArgs.get(0));
        if(mModuled != null)
            return uninstall(mModuled);
        Map<String,Object> mResult = new LinkedHashMap<>();
        mResult.put(aArgs.get(0),"is not installed");
        return mResult;
    }

    private Map<String, Object> uninstall(Dependency parent) {
        Map<String, Object> result = new HashMap<>();
        Set<Dependency> installedDependents = parent.getDependents().stream().filter(Dependency::isInstalled).collect(toSet());
        if(installedDependents.isEmpty()) {
            result.put("REMOVED",parent.getName());
            parent.setInstalled(false);

            for (Dependency dependency : parent.getDependencies()) {
                if(dependency.isInstalled()) {
                    result.putAll(uninstall(dependency));
                }
            }
        }
        else {

            result.put(parent.getName(),"is not installed.");
        }
        return result;
    }
}
