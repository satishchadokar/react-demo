package com.salesforce.tests.dependency.action;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.salesforce.tests.dependency.commands.Dependency;

/**
 * To change template using file
 */
public class InstallCommand implements ICommand {

    @Override
    public Map<String, Object> execute(List<String> aArgs) {
        Map<String, Object> mResult = new LinkedHashMap<>();
        for (String temp : aArgs) {

            Dependency mModule = Dependency.getInstance(temp);
            install(mModule, mResult);
        }
        return mResult;
    }

    private Map<String, Object> install(Dependency aCModule, Map<String, Object> aResult) {
        if (!aCModule.isInstalled()) {
            aCModule.setInstalled(true);


            for (Dependency dependency : aCModule.getDependencies()) {
                if (!dependency.isInstalled()) { 
                    install(dependency, aResult);
                }

            }
            aResult.put("Installing" ,aCModule.getName());

        }
        else {
            aResult.put(aCModule.getName(), "is already installed");

        }
        return aResult;
    }
}
